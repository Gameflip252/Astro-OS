window.TerminalApp = function(container) {
  container.innerHTML = `
    <h2 style="margin-bottom:12px;">Terminal</h2>
    <pre id="term-out" style="background:#101521;padding:12px 9px;height:180px;overflow:auto;border-radius:8px;"></pre>
    <form id="term-form" autocomplete="off" style="margin-top:10px;">
      <span style="color:#5af;">$</span>
      <input id="term-input" style="width:72%;background:#222;border:none;color:#fff;padding:7px 9px;font-family:monospace;font-size:1em;border-radius:7px;" />
      <button type="submit" style="padding:7px 16px;border-radius:7px;background:#38407a;color:#fff;border:none;margin-left:10px;">Run</button>
    </form>
  `;
  const out = container.querySelector("#term-out");
  const form = container.querySelector("#term-form");
  const input = container.querySelector("#term-input");
  out.textContent = `Astra Terminal\nType 'help' for common commands, 'helpdev' for advanced/developer commands.\n`;

  function print(str) { out.textContent += str + "\n"; out.scrollTop = out.scrollHeight; }
  form.onsubmit = function(e){
    e.preventDefault();
    const cmdline = input.value.trim();
    input.value = "";
    let res = "";
    if (cmdline === "help") {
      res = "help - Show this help\nwhoami - Show your username\nfiles - List your files\nclear - Clear terminal\nrecovery - Enter recovery mode\nhelpdev - Show developer commands";
    } else if (cmdline === "helpdev") {
      res =
        "theme [dark|light] - Set theme\n" +
        "bgcolor [hex|name] - Set desktop color\n" +
        "bgimg [url] - Set desktop background image\n" +
        "avatar [url] - Set your avatar\n" +
        "username [newname] - Change your username\n" +
        "logout - Return to account picker\n" +
        "reset - Reset user settings\n" +
        "listusers - List all Astra users\n" +
        "deluser [username] - Delete a user\n" +
        "set [key] [value] - Set a raw localStorage key\n" +
        "get [key] - Get a raw localStorage value";
    } else if (cmdline === "whoami") {
      res = (typeof getCurrentUser === "function" && getCurrentUser()) ? getCurrentUser().username : "unknown";
    } else if (cmdline === "files") {
      const files = typeof getUserFiles === "function" ? getUserFiles() : [];
      res = files.length ? files.join("\n") : "(no files)";
    } else if (cmdline === "clear") {
      out.textContent = "";
      return false;
    } else if (cmdline === "recovery") {
      res = "(entered recovery mode)";
    } else if (cmdline.startsWith("theme ")) {
      const t = cmdline.split(" ")[1];
      res = "Theme set to "+t;
    } else if (cmdline.startsWith("bgcolor ")) {
      res = "Background color set.";
    } else if (cmdline.startsWith("bgimg ")) {
      res = "Background image set.";
    } else if (cmdline.startsWith("avatar ")) {
      res = "Avatar set. Reload to see change.";
    } else if (cmdline.startsWith("username ")) {
      res = "Username updated. Reload to see change.";
    } else if (cmdline === "logout") {
      res = "(logged out)";
    } else if (cmdline === "reset") {
      res = "User settings reset (background/theme/avatar not auto-restored).";
    } else if (cmdline === "listusers") {
      res = "(none)";
    } else if (cmdline.startsWith("deluser ")) {
      res = "User deleted.";
    } else if (cmdline.startsWith("set ")) {
      res = "Set.";
    } else if (cmdline.startsWith("get ")) {
      res = "(not set)";
    } else {
      res = "Unknown command. Type 'help' or 'helpdev'.";
    }
    print("\n$ "+cmdline+"\n"+res);
    return false;
  };
};