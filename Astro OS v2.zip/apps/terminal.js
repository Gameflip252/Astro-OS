window.TerminalApp = function(container) {
  container.innerHTML = `
    <h2 style="margin-bottom:12px;">Terminal</h2>
    <pre id="term-out" style="background:#101521;padding:12px 9px;height:180px;overflow:auto;border-radius:8px;"></pre>
    <form id="term-form" autocomplete="off" style="margin-top:10px;">
      <span style="color:#5af;">$</span>
      <input id="term-input" style="width:72%;background:#222;border:none;color:#fff;padding:7px 9px;font-family:monospace;font-size:1em;border-radius:7px;" />
      <button type="submit" style="padding:7px 16px;border-radius:7px;background:#38407a;color:#fff;border:none;margin-left:10px;">Run</button>
    </form>
  `;
  const out = container.querySelector("#term-out");
  const form = container.querySelector("#term-form");
  const input = container.querySelector("#term-input");
  out.textContent = "Astra Terminal\nType 'help' for commands.\n";
  form.onsubmit = function(e){
    e.preventDefault();
    const cmd = input.value.trim();
    input.value = "";
    let res = "";
    if (cmd === "help") {
      res = "help - Show this help\nwhoami - Show your username\nfiles - List your files\nclear - Clear terminal\nrecovery - Enter recovery mode";
    } else if (cmd === "whoami") {
      res = "guest";
    } else if (cmd === "files") {
      const files = window.astraDemoFiles || [];
      res = files.length ? files.join("\n") : "(no files)";
    } else if (cmd === "clear") {
      out.textContent = "";
      return false;
    } else if (cmd === "recovery") {
      enterRecoveryMode();
      res = "(entered recovery mode)";
    } else {
      res = "Unknown command. Type 'help'.";
    }
    out.textContent += "\n$ " + cmd + "\n" + res + "\n";
    out.scrollTop = out.scrollHeight;
    return false;
  };
};

// Add this helper function to main.js or make it global
function enterRecoveryMode() {
  // Remove all windows
  for (const id in window.openWindows) {
    try { window.openWindows[id].remove(); } catch {}
  }
  window.openWindows = {};
  // Show a recovery window
  const win = document.createElement('div');
  win.className = 'window';
  win.style.zIndex = 9999;
  win.innerHTML = `
    <div class="window-header"><span class="window-title">🛠️ Recovery Mode</span></div>
    <div class="window-content" style="text-align:center;">
      <h2 style="color:#f55;">Recovery</h2>
      <p>If you broke something, you can reboot or reset background below.</p>
      <button id="reboot-btn" style="background:#38407a;color:#fff;border:none;border-radius:7px;padding:10px 22px;font-size:1.1em;margin:10px;">Reboot</button>
      <button id="reset-bg-btn" style="background:#fd3c5a;color:#fff;border:none;border-radius:7px;padding:10px 22px;font-size:1.1em;margin:10px;">Reset Background</button>
      <button id="exit-recovery-btn" style="background:#2bdf7a;color:#fff;border:none;border-radius:7px;padding:10px 22px;font-size:1.1em;margin:10px;">Exit Recovery</button>
    </div>
  `;
  document.body.appendChild(win);
  document.getElementById("reboot-btn").onclick = ()=>location.reload();
  document.getElementById("reset-bg-btn").onclick = ()=>{
    document.getElementById('desktop-bg').style.background = '';
    localStorage.removeItem('astra_desktop_bg_image');
    localStorage.removeItem('astra_desktop_bg_color');
    alert("Background reset!");
  };
  document.getElementById("exit-recovery-btn").onclick = ()=>{
    win.remove();
  };
}